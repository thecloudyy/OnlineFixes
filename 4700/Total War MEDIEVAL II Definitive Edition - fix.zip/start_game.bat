@echo off
title Medieval II Launcher
color 0A

REM Get current BAT folder
set "GAMEPATH=%~dp0"

:menu
cls
echo.
echo Choose campaign:
echo.
echo 1. Base
echo 2. Americas
echo 3. Britannia
echo 4. Crusades
echo 5. Teutonic
echo 6. Exit
echo.

set /p choice=Enter choice [1-6]: 

if "%choice%"=="1" (
    start "" "%GAMEPATH%medieval2.exe"
    exit
)

if "%choice%"=="2" (
    start "" "%GAMEPATH%medieval2.exe" --features.mod=mods/americas
    exit
)

if "%choice%"=="3" (
    start "" "%GAMEPATH%medieval2.exe" --features.mod=mods/british_isles
    exit
)

if "%choice%"=="4" (
    start "" "%GAMEPATH%medieval2.exe" --features.mod=mods/crusades
    exit
)

if "%choice%"=="5" (
    start "" "%GAMEPATH%medieval2.exe" --features.mod=mods/teutonic
    exit
)

if "%choice%"=="6" (
    exit
)

echo.
echo Invalid choice!
pause
goto menu